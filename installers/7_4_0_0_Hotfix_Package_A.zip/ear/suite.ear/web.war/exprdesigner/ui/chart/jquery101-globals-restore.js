if (!window.IS_MODELER) {
  if($){
    $.noConflict();
  }
  window.$=window.jquery101$;
  window.jQuery=window.jquery101JQuery;
}