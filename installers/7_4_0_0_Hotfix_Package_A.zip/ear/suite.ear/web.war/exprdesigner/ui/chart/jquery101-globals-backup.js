if (!window.IS_MODELER) {
  window.jquery101$ = window.$;
  window.jquery101JQuery = window.jQuery;
}